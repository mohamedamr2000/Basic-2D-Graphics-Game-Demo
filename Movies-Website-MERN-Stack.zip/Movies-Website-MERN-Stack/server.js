
const express = require('express');
const dotenv = require('dotenv');
const path = require('path');
const bodyparser = require("body-parser");
const morgan = require('morgan');
const connectDB = require('./server/database/connection');
const app = express();

dotenv.config( { path : 'config.env'} )
const PORT = process.env.PORT || 8080

//morgan
app.use(morgan('tiny'));



//mongodb connection
connectDB();

// parse request to body-parser
app.use(bodyparser.urlencoded({ extended : true}))

//views
app.set("view engine", "ejs");

app.use('/css', express.static(path.resolve(__dirname, "assets/css")))

app.use('/js', express.static(path.resolve(__dirname, "css/js/index.js")))

app.use('/css',express.static(__dirname + "/public"))

app.use('/',require('./server/routes/router'))

app.listen(3000,()=>{console.log(`Server is running on http://localhost:${PORT}`)});