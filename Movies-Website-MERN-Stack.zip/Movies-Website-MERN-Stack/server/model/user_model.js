const mongoose = require('mongoose');

var user_schema = new mongoose.Schema({
    username : {
        type : String,
    },
    password : {
        type: String,
    },
})

const userDB= mongoose.model('userDB', user_schema);

module.exports = userDB;