const express = require('express');
const route = express.Router()

const movie_controller = require('../controller/movie_controller')
const user_controller = require('../controller/user_controller')
const renders = require('../services/render')

route.get('/', renders.home);
route.get('/addmovie', renders.addmovie);
route.get('/register', renders.register);
route.get('/updatemovie', renders.updatemovie);

//api movies
route.post('/api/movies_view', movie_controller.create)
route.get('/api/movies_view', movie_controller.find);
route.put('/api/movies_view/:id', movie_controller.update);
route.delete('/api/movies_view/:id', movie_controller.delete); 







//route.get('/login', renders.login)
//route.get('/update-movie', renders.update_movie)
//route.delete('/api/movies_view/:id', movie_controller.delete); 

//route.put('/api/movies_view/:id', movie_controller.update);
//route.post('/api/login/:id', user_controller.login)


module.exports = route