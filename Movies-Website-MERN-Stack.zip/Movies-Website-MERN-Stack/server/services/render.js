
const axios = require('axios');

//movie renders
exports.home = (req, res) =>{

    axios.get('http://localhost:3000/api/movies_view')
    .then(function(response){
        console.log(response)
        res.render('index', { movies: response.data})
    })
   
}

exports.addmovie = (req, res) =>{
    res.render('addmovie');
}


//user renders
exports.register = (req, res) =>{
    res.render('register');
}

exports.login = (req, res) =>{
    res.render('login');
}

exports.updatemovie = (req, res) =>{
    axios.get('http://localhost:3000/api/movies_view', { params : { id : req.query.id }})
        .then(function(moviedata){
            res.render('updatemovie', { movie : moviedata.data})
        })
        .catch(err =>{
            res.send(err);
        })
}